'use strict';

module.exports = function countSameElements(collection) {
  return '实现练习要求，并改写该行代码。';
}
