'use strict';

module.exports = function collectSameElements(collectionA, collectionB) {
  return '实现练习要求，并改写该行代码。';
}
